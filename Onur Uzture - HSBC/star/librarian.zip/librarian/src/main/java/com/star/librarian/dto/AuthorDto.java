package com.star.librarian.dto;

import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;
import java.util.Set;

public class AuthorDto {


    @ApiModelProperty(example = "0")
    private Long id;

    @ApiModelProperty(example = "David Kynaston")
    private String name;

    @ApiModelProperty(example = "[]")
    private Set<BookSummaryDto> books;

    public AuthorDto() {
    }

    public AuthorDto(Long id, String name, Set<BookSummaryDto> books) {
        this.id = id;
        this.name = name;
        this.books = books;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public Set<BookSummaryDto> getBooks() {
        return books;
    }

    public void setBooks(Set<BookSummaryDto> books) {
        this.books = books;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AuthorDto authorDto = (AuthorDto) o;
        return getName().equals(authorDto.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName());
    }
}
