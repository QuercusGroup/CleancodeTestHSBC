package com.star.librarian.service;

import com.star.librarian.entity.Author;

import java.util.List;
import java.util.Optional;

public interface AuthorService {

    List<Author> getAll();

    Optional<Author> getById(Long id);

    Optional<Author> getByName(String name);

    Author addAuthor(Author author);

    Author addBookToAuthor(Long id, Long bookId);

    Author update(Author author);

    Author delete(Long id);
}
