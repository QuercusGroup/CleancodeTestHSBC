package com.star.librarian.dto;

import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotEmpty;
import java.util.Objects;


public class ReaderSummaryDto {
    @ApiModelProperty(example = "0")
    private Long id;

    @NotEmpty
    @ApiModelProperty(example = "Onur Uzture")
    private String name;

    public ReaderSummaryDto() {
    }

    public ReaderSummaryDto(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReaderSummaryDto reader = (ReaderSummaryDto) o;
        return name.equals(reader.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
