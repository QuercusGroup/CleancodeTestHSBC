package com.star.librarian.service.jpa;

import com.star.librarian.entity.Author;
import com.star.librarian.entity.Book;
import com.star.librarian.repository.AuthorRepository;
import com.star.librarian.repository.BookRepository;
import com.star.librarian.service.AuthorService;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class AuthorServiceImpl implements AuthorService {

    private final AuthorRepository authorRepository;
    private final BookRepository bookRepository;


    public AuthorServiceImpl(AuthorRepository authorRepository, BookRepository bookRepository) {
        this.authorRepository = authorRepository;
        this.bookRepository = bookRepository;
    }

    @Override
    public List<Author> getAll() {
        return authorRepository.findAll();
    }

    @Override
    public Optional<Author> getById(Long id) {
        return authorRepository.findById(id);
    }

    @Override
    public Optional<Author> getByName(String name) {
        return authorRepository.getByName(name);
    }

    @Override
    public Author addAuthor(Author author) {
        return authorRepository.save(author);
    }

    @Override
    public Author addBookToAuthor(Long id, Long bookId) {

        Author author = authorRepository.findById(id).orElseThrow(EntityNotFoundException::new);
        Book book = bookRepository.findById(bookId).orElseThrow(EntityNotFoundException::new);

        author.getBooks().add(book);

        book.getAuthors().add(author);
        bookRepository.save(book);

        return authorRepository.save(author);
    }

    @Override
    public Author update(Author author) {
        Author currentAuthor = authorRepository.findById(author.getId()).orElseThrow(EntityNotFoundException::new);

        currentAuthor.setName(author.getName());

        return authorRepository.save(currentAuthor);
    }

    @Override
    public Author delete(Long id) {
        Author currentAuthor = authorRepository.findById(id).orElseThrow(EntityNotFoundException::new);

        currentAuthor.getBooks().parallelStream().forEach(book -> {
            book.getAuthors().remove(currentAuthor);
            bookRepository.save(book);
        });

        authorRepository.delete(currentAuthor);
        return currentAuthor;
    }


}
