package com.star.librarian.web;

import com.star.librarian.dto.AuthorDto;
import com.star.librarian.dto.AuthorSummaryDto;
import com.star.librarian.entity.Author;
import com.star.librarian.service.AuthorService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/author")
public class AuthorController {

    @Autowired
    private ModelMapper modelMapper;

    AuthorService authorService;

    public AuthorController(AuthorService authorService) {
        this.authorService = authorService;
    }

    @GetMapping("")
    @ApiOperation(value = "Get all authors")
    public @ResponseBody
    List<AuthorDto> getAuthors() {
        return authorService
                .getAll()
                .stream()
                .map(author -> modelMapper.map(author, AuthorDto.class))
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    @ApiOperation(value = "Get author by id")
    public AuthorDto getById(@ApiParam(example = "1") @PathVariable Long id) {
        return modelMapper
                .map(authorService
                        .getById(id)
                        .orElseThrow(() -> new ResponseStatusException(
                                HttpStatus.NOT_FOUND, "Author not found")
                        ), AuthorDto.class);
    }


    @GetMapping("/find")
    @ApiOperation(value = "Get author by name")
    public AuthorDto getAuthorByName(@ApiParam(example = "David Kynaston") @RequestParam String name) {
        return modelMapper.map(authorService.getByName(name).
                orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Author not found")
                ), AuthorDto.class);
    }

    @PostMapping("")
    @ApiOperation(value = "Add author")
    public AuthorSummaryDto addAuthor(@Valid @RequestBody AuthorSummaryDto authorDto) {

        return modelMapper.map(authorService.addAuthor(modelMapper.map(authorDto, Author.class)), AuthorSummaryDto.class);
    }

    @PostMapping("{id}/book/{bookId}")
    @ApiOperation(value = "Add a book to author")
    public AuthorDto addBookToAuthor(@ApiParam(example = "1") @PathVariable Long id, @ApiParam(example = "1") @PathVariable Long bookId) {

        return modelMapper.map(authorService.addBookToAuthor(id, bookId), AuthorDto.class);
    }

    @PutMapping
    @ApiOperation(value = "Update author")
    public AuthorSummaryDto updateAuthor(@Valid @RequestBody AuthorSummaryDto authorDto) {
        return modelMapper.map(authorService.update(modelMapper.map(authorDto, Author.class)), AuthorSummaryDto.class);

    }

    @DeleteMapping({"/{id}"})
    @ApiOperation(value = "Delete author")
    public AuthorSummaryDto deleteAuthor(@ApiParam(example = "1") @PathVariable Long id) {
        return modelMapper.map(authorService.delete(id), AuthorSummaryDto.class);

    }
}
