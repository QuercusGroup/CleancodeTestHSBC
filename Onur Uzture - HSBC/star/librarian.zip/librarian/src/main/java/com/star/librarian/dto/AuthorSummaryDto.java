package com.star.librarian.dto;

import io.swagger.annotations.ApiModelProperty;

import java.util.Objects;

public class AuthorSummaryDto {


    @ApiModelProperty(example = "0")
    private Long id;

    @ApiModelProperty(example = "David Kynaston")
    private String name;

    public AuthorSummaryDto() {
    }

    public AuthorSummaryDto(Long id, String name) {
        this.id = id;
        this.name = name;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }


    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        AuthorSummaryDto authorDto = (AuthorSummaryDto) o;
        return getName().equals(authorDto.getName());
    }

    @Override
    public int hashCode() {
        return Objects.hash(getName());
    }
}
