package com.star.librarian.web;


import com.star.librarian.dto.ReaderDto;
import com.star.librarian.dto.ReaderSummaryDto;
import com.star.librarian.entity.Reader;
import com.star.librarian.service.ReaderService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/reader")
public class ReaderController {

    @Autowired
    private ModelMapper modelMapper;

    ReaderService readerService;

    public ReaderController(ReaderService readerService) {
        this.readerService = readerService;
    }

    @GetMapping("")
    @ApiOperation(value = "Get all readers")
    public @ResponseBody
    List<ReaderDto> getReaders() {
        return readerService
                .getAll()
                .stream()
                .map(reader -> modelMapper.map(reader, ReaderDto.class))
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    @ApiOperation(value = "Get reader by id")
    public ReaderDto getById(@ApiParam(example = "1") @PathVariable Long id) {
        return modelMapper.map(readerService.getById(id).
                orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Reader not found")
                ), ReaderDto.class);
    }

    @PostMapping("")
    @ApiOperation(value = "Add reader")
    public ReaderSummaryDto addReader(@Valid @RequestBody ReaderSummaryDto readerDto) {

        return modelMapper.map(readerService.addReader(modelMapper.map(readerDto, Reader.class)), ReaderSummaryDto.class);
    }

    @PutMapping
    @ApiOperation(value = "Update reader")
    public ReaderSummaryDto updateReader(@Valid @RequestBody ReaderSummaryDto readerDto) {
        return modelMapper.map(readerService.update(modelMapper.map(readerDto, Reader.class)), ReaderSummaryDto.class);

    }

    @DeleteMapping({"/{id}"})
    @ApiOperation(value = "Delete reader")
    public ReaderSummaryDto deleteReader(@ApiParam(example = "1") @PathVariable Long id) {
        return modelMapper.map(readerService.delete(id), ReaderSummaryDto.class);

    }
}
