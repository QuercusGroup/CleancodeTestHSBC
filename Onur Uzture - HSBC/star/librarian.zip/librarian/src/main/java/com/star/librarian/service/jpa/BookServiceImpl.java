package com.star.librarian.service.jpa;

import com.star.librarian.entity.Author;
import com.star.librarian.entity.Book;
import com.star.librarian.entity.Reader;
import com.star.librarian.repository.AuthorRepository;
import com.star.librarian.repository.BookRepository;
import com.star.librarian.repository.ReaderRepository;
import com.star.librarian.service.BookService;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class BookServiceImpl implements BookService {

    private final BookRepository bookRepository;
    private final AuthorRepository authorRepository;
    private final ReaderRepository readerRepository;

    public BookServiceImpl(BookRepository bookRepository, AuthorRepository authorRepository, ReaderRepository readerRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
        this.readerRepository = readerRepository;
    }

    @Override
    public List<Book> getAll() {
        return bookRepository.findAll();
    }

    @Override
    public Optional<Book> getById(Long id) {
        return bookRepository.findById(id);
    }

    @Override
    public Optional<Book> getByIsbn(String isbn) {
        return bookRepository.getByIsbn(isbn);
    }

    @Override
    public Book addBook(Book book) {
        return bookRepository.save(book);
    }

    @Override
    public Book addAuthorToBook(Long id, Long authorId) {

        Book book = bookRepository.findById(id).orElseThrow(EntityNotFoundException::new);
        Author author = authorRepository.findById(authorId).orElseThrow(EntityNotFoundException::new);

        book.getAuthors().add(author);

        author.getBooks().add(book);

        authorRepository.save(author);

        return bookRepository.save(book);
    }

    @Override
    public Book rentABook(Long id, Long readerId) {

        Book book = bookRepository.findById(id).orElseThrow(EntityNotFoundException::new);

        if (book.getCount() <= 0) {
            throw new EntityNotFoundException("Not enough books to rent");
        }

        Reader reader = readerRepository.findById(readerId).orElseThrow(EntityNotFoundException::new);

        if (reader.getBook() != null) {
            throw new IllegalArgumentException("Reader already has a book");
        }

        book.setCount(book.getCount() - 1);
        book.getReaders().add(reader);

        reader.setBook(book);
        readerRepository.save(reader);

        return bookRepository.save(book);
    }

    @Override
    public Book returnABook(Long id, Long readerId) {

        Book book = bookRepository.findById(id).orElseThrow(EntityNotFoundException::new);

        Reader reader = readerRepository.findById(readerId).orElseThrow(EntityNotFoundException::new);

        if (reader.getBook() == null || reader.getBook().getId() != id) {
            throw new IllegalArgumentException("Reader doesn't have this book");
        }

        book.getReaders().remove(reader);
        book.setCount(book.getCount() + 1);

        reader.setBook(null);
        readerRepository.save(reader);

        return bookRepository.save(book);
    }

    @Override
    public Book update(Book book) {
        Book currentBook = bookRepository.findById(book.getId()).orElseThrow(EntityNotFoundException::new);

        currentBook.setCount(book.getCount());
        currentBook.setTitle(book.getTitle());
        currentBook.setShelf(book.getShelf());
        currentBook.setPrice(book.getPrice());
        currentBook.setLine(book.getLine());
        currentBook.setIsbn(book.getIsbn());


        return bookRepository.save(currentBook);
    }

    @Override
    public Book delete(Long id) {
        Book currentBook = bookRepository.findById(id).orElseThrow(EntityNotFoundException::new);

        currentBook.getAuthors().parallelStream().forEach(author -> {
            author.getBooks().remove(currentBook);
            authorRepository.save(author);
        });

        currentBook.getReaders().parallelStream().forEach(reader -> {
            reader.setBook(null);
            readerRepository.save(reader);
        });

        bookRepository.delete(currentBook);
        return currentBook;
    }
}
