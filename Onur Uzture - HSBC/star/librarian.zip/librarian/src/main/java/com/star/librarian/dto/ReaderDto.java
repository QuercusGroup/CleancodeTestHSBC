package com.star.librarian.dto;

import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotEmpty;
import java.util.Objects;


public class ReaderDto {
    @ApiModelProperty(example = "0")
    private Long id;

    @NotEmpty
    @ApiModelProperty(example = "Onur Uzture")
    private String name;

    @ApiModelProperty(example = "[]")
    private BookSummaryDto book;

    public ReaderDto() {
    }

    public ReaderDto(Long id, String name, BookSummaryDto book) {
        this.id = id;
        this.name = name;
        this.book = book;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public BookSummaryDto getBook() {
        return book;
    }

    public void setBook(BookSummaryDto book) {
        this.book = book;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        ReaderDto reader = (ReaderDto) o;
        return name.equals(reader.name);
    }

    @Override
    public int hashCode() {
        return Objects.hash(name);
    }
}
