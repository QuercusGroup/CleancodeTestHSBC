package com.star.librarian.dto;

import io.swagger.annotations.ApiModelProperty;

import javax.validation.constraints.NotEmpty;
import javax.validation.constraints.Size;
import java.util.Objects;
import java.util.Set;

public class BookDto {

    @ApiModelProperty(example = "0")
    private Long id;

    @Size(min = 10, max = 14)
    @ApiModelProperty(example = "1781250553")
    private String isbn;

    @NotEmpty
    @ApiModelProperty(example = "The Lion Wakes: A Modern History of HSBC")
    private String title;

    @ApiModelProperty(example = "[]")
    private Set<AuthorSummaryDto> authors;

    @ApiModelProperty(example = "A4")
    private String shelf;

    @ApiModelProperty(example = "3")
    private Integer line;

    @ApiModelProperty(example = "2")
    private Integer count;

    @ApiModelProperty(example = "20")
    private Integer price;


    @ApiModelProperty(example = "[]")
    private Set<ReaderSummaryDto> readers;

    public BookDto() {
    }

    public BookDto(Long id, String isbn, String title, Set<AuthorSummaryDto> authors, String shelf, Integer line, Integer count, Integer price, Set<ReaderSummaryDto> readers) {
        this.id = id;
        this.isbn = isbn;
        this.title = title;
        this.authors = authors;
        this.shelf = shelf;
        this.line = line;
        this.count = count;
        this.price = price;
        this.readers = readers;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getIsbn() {
        return isbn;
    }

    public void setIsbn(String isbn) {
        this.isbn = isbn;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public Set<AuthorSummaryDto> getAuthors() {
        return authors;
    }

    public void setAuthors(Set<AuthorSummaryDto> authors) {
        this.authors = authors;
    }

    public String getShelf() {
        return shelf;
    }

    public void setShelf(String shelf) {
        this.shelf = shelf;
    }

    public Integer getLine() {
        return line;
    }

    public void setLine(Integer line) {
        this.line = line;
    }

    public Integer getCount() {
        return count;
    }

    public void setCount(Integer count) {
        this.count = count;
    }

    public Integer getPrice() {
        return price;
    }

    public void setPrice(Integer price) {
        this.price = price;
    }

    public Set<ReaderSummaryDto> getReaders() {
        return readers;
    }

    public void setReaders(Set<ReaderSummaryDto> readers) {
        this.readers = readers;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        BookDto book = (BookDto) o;
        return isbn.equals(book.isbn);
    }

    @Override
    public int hashCode() {
        return Objects.hash(isbn);
    }
}
