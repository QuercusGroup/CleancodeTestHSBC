package com.star.librarian.service.jpa;

import com.star.librarian.entity.Reader;
import com.star.librarian.repository.ReaderRepository;
import com.star.librarian.service.ReaderService;
import org.springframework.stereotype.Service;

import javax.persistence.EntityNotFoundException;
import java.util.List;
import java.util.Optional;

@Service
public class ReaderServiceImpl implements ReaderService {

    private final ReaderRepository readerRepository;

    public ReaderServiceImpl(ReaderRepository readerRepository) {
        this.readerRepository = readerRepository;
    }

    @Override
    public List<Reader> getAll() {
        return readerRepository.findAll();
    }

    @Override
    public Optional<Reader> getById(Long id) {
        return readerRepository.findById(id);
    }

    @Override
    public Reader addReader(Reader reader) {
        return readerRepository.save(reader);
    }

    @Override
    public Reader update(Reader reader) {
        Reader currentReader = readerRepository.findById(reader.getId()).orElseThrow(EntityNotFoundException::new);

        currentReader.setName(reader.getName());

        return readerRepository.save(currentReader);
    }

    @Override
    public Reader delete(Long id) {
        Reader currentReader = readerRepository.findById(id).orElseThrow(EntityNotFoundException::new);

        if (currentReader.getBook() != null) {
            throw new IllegalArgumentException("Reader cannot be removed before returning book");
        }

        readerRepository.delete(currentReader);

        return currentReader;

    }
}
