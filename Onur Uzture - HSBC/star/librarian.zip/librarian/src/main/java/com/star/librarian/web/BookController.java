package com.star.librarian.web;

import com.star.librarian.dto.BookDto;
import com.star.librarian.dto.BookSummaryDto;
import com.star.librarian.entity.Book;
import com.star.librarian.service.BookService;
import io.swagger.annotations.ApiOperation;
import io.swagger.annotations.ApiParam;
import org.modelmapper.ModelMapper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.server.ResponseStatusException;

import javax.validation.Valid;
import java.util.List;
import java.util.stream.Collectors;

@RestController
@RequestMapping("/api/v1/book")
public class BookController {

    @Autowired
    private ModelMapper modelMapper;

    BookService bookService;

    public BookController(BookService bookService) {
        this.bookService = bookService;
    }

    @GetMapping("")
    @ApiOperation(value = "Get all books")
    public @ResponseBody
    List<BookDto> getBooks() {
        return bookService
                .getAll()
                .stream()
                .map(book -> modelMapper.map(book, BookDto.class))
                .collect(Collectors.toList());
    }

    @GetMapping("/{id}")
    @ApiOperation(value = "Get book by id")
    public BookDto getById(@ApiParam(example = "1") @PathVariable Long id) {
        return modelMapper
                .map(bookService
                        .getById(id)
                        .orElseThrow(() -> new ResponseStatusException(
                                HttpStatus.NOT_FOUND, "Book not found")
                        ), BookDto.class);
    }

    @GetMapping("/find")
    @ApiOperation(value = "Get book by isbn")
    public BookDto getByIsbn(@ApiParam(example = "1781250553") @RequestParam String isbn) {
        return modelMapper.map(bookService
                .getByIsbn(isbn)
                .orElseThrow(() -> new ResponseStatusException(
                        HttpStatus.NOT_FOUND, "Book not found")
                ), BookDto.class);
    }

    @PostMapping("")
    @ApiOperation(value = "Add book")
    public BookSummaryDto addBook(@Valid @RequestBody BookSummaryDto bookDto) {

        return modelMapper.map(bookService.addBook(modelMapper.map(bookDto, Book.class)), BookSummaryDto.class);
    }

    @PostMapping("{id}/author/{authorId}")
    @ApiOperation(value = "Add a author to book")
    public BookDto addAuthorToBook(@ApiParam(example = "1") @PathVariable Long id, @ApiParam(example = "1") @PathVariable Long authorId) {

        return modelMapper.map(bookService.addAuthorToBook(id, authorId), BookDto.class);
    }

    @PostMapping("{id}/reader/rent/{readerId}")
    @ApiOperation(value = "Rent a book to a reader")
    public BookDto rentABook(@ApiParam(example = "1") @PathVariable Long id, @ApiParam(example = "1") @PathVariable Long readerId) {

        return modelMapper.map(bookService.rentABook(id, readerId), BookDto.class);
    }

    @PostMapping("{id}/reader/return/{readerId}")
    @ApiOperation(value = "Return a book from a reader")
    public BookDto returnABook(@ApiParam(example = "1") @PathVariable Long id, @ApiParam(example = "1") @PathVariable Long readerId) {

        return modelMapper.map(bookService.returnABook(id, readerId), BookDto.class);
    }

    @PutMapping
    @ApiOperation(value = "Update book")
    public BookSummaryDto updateBook(@Valid @RequestBody BookSummaryDto bookDto) {
        return modelMapper.map(bookService.update(modelMapper.map(bookDto, Book.class)), BookSummaryDto.class);

    }

    @DeleteMapping({"/{id}"})
    @ApiOperation(value = "Delete book")
    public BookSummaryDto deleteBook(@ApiParam(example = "1") @PathVariable Long id) {
        return modelMapper.map(bookService.delete(id), BookSummaryDto.class);

    }
}
