package com.star.librarian.service;

import com.star.librarian.entity.Book;

import java.util.List;
import java.util.Optional;

public interface BookService {

    List<Book> getAll();

    Optional<Book> getById(Long id);

    Optional<Book> getByIsbn(String isbn);

    Book addBook(Book book);

    Book addAuthorToBook(Long id, Long authorId);

    Book rentABook(Long id, Long readerId);

    Book returnABook(Long id, Long readerId);

    Book update(Book book);

    Book delete(Long id);

}
