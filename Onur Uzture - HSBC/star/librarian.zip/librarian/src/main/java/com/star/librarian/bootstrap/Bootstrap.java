package com.star.librarian.bootstrap;

import com.star.librarian.entity.Author;
import com.star.librarian.entity.Book;
import com.star.librarian.entity.Reader;
import com.star.librarian.repository.AuthorRepository;
import com.star.librarian.repository.BookRepository;
import com.star.librarian.repository.ReaderRepository;
import org.springframework.stereotype.Component;

import java.util.Set;

@Component
public class Bootstrap {

    BookRepository bookRepository;
    AuthorRepository authorRepository;
    ReaderRepository readerRepository;

    public Bootstrap(BookRepository bookRepository, AuthorRepository authorRepository, ReaderRepository readerRepository) {
        this.bookRepository = bookRepository;
        this.authorRepository = authorRepository;
        this.readerRepository = readerRepository;
    }

    public void bootstrap() {


        Author author1 = new Author();
        author1.setName("David Kynaston");

        Author author2 = new Author();
        author2.setName("Richard Roberts");

        Author author3 = new Author();
        author3.setName("Anna Coulling");

        author1 = authorRepository.save(author1);
        author2 = authorRepository.save(author2);
        author3 = authorRepository.save(author3);

        Book book1 = new Book();
        book1.setCount(1);
        book1.setIsbn("1781250553");
        book1.setLine(5);
        book1.setPrice(20);
        book1.setShelf("A4");
        book1.setTitle("The Lion Wakes: A Modern History of HSBC");

        book1 = bookRepository.save(book1);

        author1.setBooks(Set.of(book1));
        author2.setBooks(Set.of(book1));

        book1.setAuthors(Set.of(author1, author2));

        author1 = authorRepository.save(author1);
        author2 = authorRepository.save(author2);

        book1 = bookRepository.save(book1);


        Book book2 = new Book();
        book2.setCount(2);
        book2.setIsbn("1491249390");
        book2.setLine(2);
        book2.setPrice(20);
        book2.setShelf("B2");
        book2.setTitle("A Complete Guide To Volume Price Analysis");

        book2 = bookRepository.save(book2);

        author3.setBooks(Set.of(book2));
        book2.setAuthors(Set.of(author3));

        author3 = authorRepository.save(author3);
        book2 = bookRepository.save(book2);

        Reader reader1 = new Reader();
        reader1.setName("Onur Uzture");
        reader1.setBook(book1);
        reader1 = readerRepository.save(reader1);


        book1.setReaders(Set.of(reader1));
        book1 = bookRepository.save(book1);


    }

}
