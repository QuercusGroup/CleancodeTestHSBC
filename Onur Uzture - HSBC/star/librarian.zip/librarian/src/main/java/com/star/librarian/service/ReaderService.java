package com.star.librarian.service;

import com.star.librarian.entity.Reader;

import java.util.List;
import java.util.Optional;


public interface ReaderService {

    List<Reader> getAll();

    Optional<Reader> getById(Long id);

    Reader addReader(Reader reader);

    Reader update(Reader reader);

    Reader delete(Long id);

}
