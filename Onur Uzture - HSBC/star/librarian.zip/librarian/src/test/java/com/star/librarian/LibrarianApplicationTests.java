package com.star.librarian;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LibrarianApplicationTests {

    @Test
    void contextLoads() {
    }

}
